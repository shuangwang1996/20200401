
This project is used by the zybo_hdmi_in SDSoC platform. It is version
controlled here, but not meant to be used as a reference project, so
no wiki documentation or tutorials will be created for it. If you would
like to use the zybo_hdmi_in SDSoC platform, please goto the following
site for instructions:

https://reference.digilentinc.com/vivado:sdsoc 


 
